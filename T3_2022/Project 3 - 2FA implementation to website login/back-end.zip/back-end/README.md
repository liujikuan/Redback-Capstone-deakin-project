# backend
Backend server code

## Setup instructions

Download or clone the repository.

Run `npm install` command in the repository root directory to install all modules.

Add the .env file into root directory (contains secret information, ask for the file if needed).

Add an empty folder into root directory for uploaded files
